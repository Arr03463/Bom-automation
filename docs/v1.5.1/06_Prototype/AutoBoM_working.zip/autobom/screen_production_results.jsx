/* global React, Icon, StatusBadge, RoleTag, SupplierTag, Banner, EmptyState, TraceabilityStrip,
   BomTable, Totals, PipelineHeader, bomById, useStore, storeActions, PROJECTS, CATALOG, BOM_BADGE, fmtUSD, fmtInt, bomMeta */
const { useState: useStateRes, useRef: useRefRes } = React;

/* ---- Push-Back Composer (modal) ---- structured: reason + urgency + flagged lines,
     or a missing-component request (a part the master BOM doesn't have). ---- */
function ExceptionComposer({ bom, lineNos, startMissing, onClose }) {
  const [reason, setReason] = useStateRes('unsourceable');
  const [urgency, setUrgency] = useStateRes('standard');
  const [note, setNote] = useStateRes('');
  const [missing, setMissing] = useStateRes(!!startMissing);
  const [acr, setAcr] = useStateRes({ mpn: '', description: '', characteristics: '', quantityPerBoard: 1, designator: '' });
  const [sent, setSent] = useStateRes(false);
  const lines = bom.items.filter(i => lineNos.has(i.no));
  const REASONS = [['obsolete', 'Obsolete'], ['eol', 'EOL'], ['unsourceable', 'Unsourceable'], ['zero-stock', 'Zero stock'], ['other', 'Other']];
  const canSend = missing ? acr.description.trim().length > 0 : lines.length > 0;
  const send = () => {
    if (missing) storeActions.sendPushback(bom.id, { reason: 'missing-component', urgency, note,
      addedComponentRequest: { mpn: acr.mpn.trim() || null, description: acr.description.trim(), characteristics: acr.characteristics.trim(), quantityPerBoard: +acr.quantityPerBoard || 1, designator: acr.designator.trim() || null } });
    else storeActions.sendPushback(bom.id, { lineNos: [...lineNos], reason, urgency, note });
    setSent(true);
  };
  const setA = (k, v) => setAcr(a => ({ ...a, [k]: v }));
  return (
    <div className="modal-wrap"><div className="scrim" onClick={onClose} />
      <div className="modal" style={{ width: 580, position: 'relative', zIndex: 95 }}>
        {!sent ? <>
          <div className="modal-head"><div className="mh-title" style={{ display: 'flex', alignItems: 'center', gap: 9 }}><Icon name="alert" size={18} style={{ color: 'var(--danger)' }} />Send Push-Back to {bom.creator}</div></div>
          <div className="modal-body">
            <div className="seg-toggle" style={{ marginBottom: 12 }}>
              <button className={!missing ? 'on' : ''} onClick={() => setMissing(false)}>Flagged lines{lines.length ? ` · ${lines.length}` : ''}</button>
              <button className={missing ? 'on' : ''} onClick={() => setMissing(true)}>Missing component</button>
            </div>
            <div style={{ display: 'flex', gap: 14, marginBottom: 12, flexWrap: 'wrap' }}>
              {!missing && <label className="field" style={{ flex: 1, minWidth: 180 }}><span className="fl">Reason</span>
                <select className="select" value={reason} onChange={e => setReason(e.target.value)}>{REASONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>}
              <label className="field" style={{ flex: 1, minWidth: 180 }}><span className="fl">Urgency</span>
                <div className="seg-toggle"><button className={urgency === 'standard' ? 'on' : ''} onClick={() => setUrgency('standard')}>Standard</button><button className={urgency === 'blocking' ? 'on' : ''} onClick={() => setUrgency('blocking')}>Blocking</button></div></label>
            </div>
            {!missing ? <>
              <p style={{ marginTop: 0 }} className="secondary">These {lines.length} line{lines.length !== 1 ? 's' : ''} go to the Designer, who will <strong>recommend</strong> replacements via characteristic search. The BOM stays in EXCEPTIONS until Production applies them.</p>
              <div className="tbl-wrap" style={{ marginBottom: 14 }}><table className="bom"><thead><tr><th>MPN</th><th>Reason</th></tr></thead><tbody>
                {lines.map(l => <tr key={l.no} className="exception"><td className="mono" style={{ fontWeight: 600 }}>{l.mpn}</td><td className="secondary">{l.exReason || 'Needs engineering review'}</td></tr>)}
                {lines.length === 0 && <tr><td colSpan={2} className="caption">No lines selected — pick lines on the results table, or switch to Missing component.</td></tr>}
              </tbody></table></div>
            </> : <>
              <p style={{ marginTop: 0 }} className="secondary">Request a component the master BOM doesn't have. The Designer recommends a part to <strong>add</strong> as a new line; Production applies it.</p>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                <label className="field"><span className="fl">MPN <span className="muted">(if known)</span></span><input className="input mono" value={acr.mpn} onChange={e => setA('mpn', e.target.value)} /></label>
                <label className="field"><span className="fl">Designator <span className="muted">(optional)</span></span><input className="input mono" value={acr.designator} onChange={e => setA('designator', e.target.value)} placeholder="e.g. C42" /></label>
                <label className="field" style={{ gridColumn: '1 / -1' }}><span className="fl">Description <span style={{ color: 'var(--danger)' }}>(required)</span></span><input className="input" value={acr.description} onChange={e => setA('description', e.target.value)} placeholder="e.g. Bulk cap, 47µF 25V, low ESR" /></label>
                <label className="field" style={{ gridColumn: '1 / -1' }}><span className="fl">Characteristics <span className="muted">(free text — seeds the Designer's search)</span></span><input className="input" value={acr.characteristics} onChange={e => setA('characteristics', e.target.value)} placeholder="47µF, 25V, X7R, 1206" /></label>
                <label className="field"><span className="fl">Qty / board</span><input className="input" type="number" min="1" value={acr.quantityPerBoard} onChange={e => setA('quantityPerBoard', e.target.value)} /></label>
              </div>
            </>}
            <label className="field" style={{ marginTop: 4 }}><span className="fl">Note to designer <span className="muted">(optional)</span></span>
              <textarea className="textarea" placeholder="e.g. IRFB4110PBF may be discontinued — please confirm or supply a replacement." value={note} onChange={e => setNote(e.target.value)} /></label>
          </div>
          <div className="modal-foot"><button className="btn" onClick={onClose}>Cancel</button><button className="btn danger" disabled={!canSend} onClick={send}><Icon name="send" size={15} />Send Push-Back</button></div>
        </> : <>
          <div className="modal-head"><div className="mh-title" style={{ display: 'flex', alignItems: 'center', gap: 9 }}><Icon name="check" size={18} style={{ color: 'var(--success)' }} />Push-Back sent</div></div>
          <div className="modal-body">A notification went to <strong>{bom.creator}</strong>. The Designer will recommend {missing ? 'a component to add' : 'replacements'} via characteristic search; you'll get a <strong>Replacements recommended</strong> card on your dashboard to Apply.</div>
          <div className="modal-foot"><button className="btn primary" onClick={onClose}>Done</button></div>
        </>}
      </div>
    </div>
  );
}

/* ---- Sourcing Results ---- */
function SourcingResultsScreen({ id, go }) {
  const b = bomById(id);
  const [sel, setSel] = useStateRes(new Set());
  const [composer, setComposer] = useStateRes(false);
  const [missingMode, setMissingMode] = useStateRes(false);
  if (!b) return <div className="page"><EmptyState icon="boms" title="BOM not found." /></div>;
  const m = bomMeta(b);
  const exceptions = b.items.filter(i => i.status === 'needs-review' || i.status === 'exception');
  const toggle = (no) => setSel(s => { const n = new Set(s); n.has(no) ? n.delete(no) : n.add(no); return n; });
  const score = { mouser: b.items.filter(i => i.supplier === 'mouser').length, digikey: b.items.filter(i => i.supplier === 'digikey').length, wall: b.items.filter(i => i.status === 'check-wall').length, review: exceptions.length };

  return (
    <div className="page page-wide">
      <PipelineHeader b={b} go={go} stage="results" />
      <div className="scorecard" style={{ marginTop: 16 }}>
        <div className="stat"><div className="st-label"><span className="dot" style={{ background: 'var(--supplier-mouser)' }} /> Sourced — Mouser</div><div className="st-num" style={{ color: 'var(--supplier-mouser)' }}>{score.mouser}</div></div>
        <div className="stat"><div className="st-label"><span className="dot" style={{ background: 'var(--supplier-digikey)' }} /> Sourced — DigiKey</div><div className="st-num" style={{ color: 'var(--supplier-digikey)' }}>{score.digikey}</div></div>
        <div className="stat"><div className="st-label"><Icon name="alert" size={13} style={{ color: 'var(--warning)' }} /> Check wall</div><div className="st-num" style={{ color: 'var(--warning)' }}>{score.wall}</div></div>
        <div className="stat"><div className="st-label"><Icon name="alert" size={13} style={{ color: 'var(--danger)' }} /> Needs review</div><div className="st-num" style={{ color: score.review ? 'var(--danger)' : 'var(--success)' }}>{score.review}</div></div>
      </div>

      <div style={{ marginTop: 16 }}>
        {score.review > 0 ? (
          <Banner kind="danger" icon="alert" title={`${score.review} line${score.review > 1 ? 's' : ''} could not be sourced`}
            actions={<button className="btn sm danger" disabled={sel.size === 0} onClick={() => setComposer(true)}><Icon name="send" size={14} />Send {sel.size || ''} to designer</button>}>
            Select the lines to push back to engineering, then send an exception report. The rest are ready to package.
          </Banner>
        ) : (
          <Banner kind="info" icon="check" title="All lines sourced — ready to package"
            actions={<button className="btn sm primary" onClick={() => go({ screen: 'p.procurement', id: b.id })}><Icon name="package" size={14} />Create package</button>}>
            Every line has a supplier assignment. Create the procurement package to hand off to Purchasing.
          </Banner>
        )}
      </div>

      <div style={{ marginTop: 14 }}>
        <BomTable items={b.items} editable={false} showSource selectable={score.review > 0} selected={sel} onToggle={toggle}
          defaultSort={{ col: 'ext', dir: -1 }} />
        <div className="tbl-wrap" style={{ borderTop: 0, borderRadius: 0, marginTop: -1 }}><Totals items={b.items} /></div>
      </div>

      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 18 }}>
        <button className="btn" onClick={() => { setMissingMode(true); setComposer(true); }}><Icon name="plus" size={15} />Request missing component</button>
        {score.review > 0 && <button className="btn danger" disabled={sel.size === 0} onClick={() => { setMissingMode(false); setComposer(true); }}><Icon name="send" size={15} />Send Push-Back to designer</button>}
        <button className="btn primary" disabled={score.review > 0} onClick={() => go({ screen: 'p.procurement', id: b.id })}><Icon name="package" size={15} />Create Procurement Package</button>
      </div>

      {composer && <ExceptionComposer bom={b} lineNos={sel} startMissing={missingMode} onClose={() => { setComposer(false); setMissingMode(false); setSel(new Set()); go({ screen: 'p.bomOverview', id: b.id }); }} />}
    </div>
  );
}

/* ---- Procurement Package ---- */
function ProcurementPackageScreen({ id, go }) {
  const b = bomById(id);
  const [pb, setPb] = useStateRes(b && b.partsbox ? 'created' : 'idle'); // idle | creating | created | failed
  const [note, setNote] = useStateRes('');
  const [sendOpen, setSendOpen] = useStateRes(false);
  if (!b) return <div className="page"><EmptyState icon="boms" title="BOM not found." /></div>;
  const m = bomMeta(b);
  const createPB = () => { setPb('creating'); setTimeout(() => { storeActions.createPackage(b.id); setPb('created'); }, 1100); };
  const submit = (n) => { storeActions.submitBomToPurchasing(b.id, n != null ? n : note); go({ screen: 'p.bomOverview', id: b.id }); };

  return (
    <div className="page page-wide">
      <PipelineHeader b={b} go={go} stage="procurement" />
      <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 20, alignItems: 'start', marginTop: 16 }}>
        <div>
          <div className="panel" style={{ marginBottom: 16 }}>
            <div className="panel-head"><Icon name="package" size={16} /><span className="ph-title">PartsBox project</span></div>
            <div className="panel-body">
              {pb === 'idle' && <>
                <p style={{ marginTop: 0 }} className="secondary">Create a PartsBox project and import this BOM so Purchasing receives a structured, supplier-ready package.</p>
                <button className="btn primary" onClick={createPB}><Icon name="plus" size={15} />Create PartsBox project & import</button>
              </>}
              {pb === 'creating' && <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}><span className="spinner" /><span>Creating PartsBox project and importing {m.lines} lines…</span></div>}
              {pb === 'created' && <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                <div className="attn-icon" style={{ background: 'var(--success-soft)', color: 'var(--success)' }}><Icon name="check" size={18} /></div>
                <div style={{ flex: 1 }}><div style={{ fontWeight: 600 }}>PartsBox project created</div><div className="caption mono">{b.partsbox || 'PB-' + b.id.replace('BOM-', '')} · {m.lines} lines imported</div></div>
                <a className="btn ghost sm" href="#" onClick={e => e.preventDefault()}><Icon name="external" size={14} />Open</a>
              </div>}
              {pb === 'failed' && <Banner kind="danger" icon="x" title="PartsBox import failed"
                actions={<button className="btn sm" onClick={createPB}>Retry</button>}>The PartsBox API returned an error (503). You can retry, or download the BOM as CSV and import manually.</Banner>}
              {pb !== 'failed' && pb !== 'idle' && <button className="btn-link" style={{ marginTop: 10 }} onClick={() => setPb('failed')}>Simulate failure</button>}
            </div>
          </div>
          <BomTable items={b.items} editable={false} showSource defaultSort={{ col: 'ext', dir: -1 }} maxHeight={360} />
          <div className="tbl-wrap" style={{ borderTop: 0, borderRadius: 0, marginTop: -1 }}><Totals items={b.items} /></div>
        </div>

        <div className="card" style={{ padding: 16, position: 'sticky', top: 0 }}>
          <div className="h2" style={{ marginBottom: 12 }}>Submit to Purchasing</div>
          <dl className="kv" style={{ marginBottom: 14 }}>
            <dt>BOM</dt><dd style={{ fontWeight: 600 }}>{b.name}</dd>
            <dt>PCB Project</dt><dd>{PROJECTS[b.project].name}</dd>
            <dt>Build qty</dt><dd>{fmtInt(b.buildQty)} +{b.overage}%</dd>
            <dt>Lines</dt><dd>{m.lines}</dd>
            <dt>Est. total</dt><dd className="mono" style={{ fontWeight: 600 }}>{fmtUSD(m.total)}</dd>
            <dt>PartsBox</dt><dd>{pb === 'created' ? <span style={{ color: 'var(--success)' }}>Ready</span> : <span className="muted">Not created</span>}</dd>
          </dl>
          <button className="btn primary lg" style={{ width: '100%' }} disabled={pb === 'idle' || pb === 'creating'} onClick={() => setSendOpen(true)}><Icon name="send" size={16} />Send to purchasing bucket{pb === 'failed' && ' — flag PartsBox failure'}</button>
          {pb === 'idle' && <div className="caption" style={{ textAlign: 'center', marginTop: 8 }}>Create the PartsBox package first — or skip with [Retry] if the API is down</div>}
          {pb === 'failed' && <div className="caption" style={{ textAlign: 'center', marginTop: 8, color: 'var(--warning)' }}><Icon name="alert" size={13} /> Sending allowed — the lines will be flagged for Purchasing</div>}
          <div className="caption" style={{ marginTop: 12, display: 'flex', gap: 7, alignItems: 'flex-start' }}><Icon name="lock" size={14} style={{ marginTop: 1 }} />Sending locks this BOM. Engineering content becomes read-only while its lines pool toward the next purchasing batch.</div>
        </div>
      </div>
      {sendOpen && window.SendToBucketPanel && <window.SendToBucketPanel title="Send to purchasing bucket" sourceId={b.id} items={b.items} allowRecheck={false}
        summaryRows={[['BOM', b.name], ['PCB Project', PROJECTS[b.project].name], ['Build qty', `${fmtInt(b.buildQty)} +${b.overage}%`], ['Lines', m.lines], ['Est. total', <span className="mono" style={{ fontWeight: 600 }}>{fmtUSD(m.total)}</span>]]}
        onClose={() => setSendOpen(false)} onConfirm={(n) => { setSendOpen(false); submit(n); }} />}
    </div>
  );
}

Object.assign(window, { SourcingResultsScreen, ProcurementPackageScreen, ExceptionComposer });
