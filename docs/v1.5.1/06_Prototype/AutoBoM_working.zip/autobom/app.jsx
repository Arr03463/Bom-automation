/* global React, ReactDOM, Sidebar, TopRail, Breadcrumbs, NotificationPanel, SearchOverlay, Icon, EmptyState, RoleTag,
   useStore, storeActions, getState, buildCrumbs, navKeyForScreen, ROLE_META */
const { useState, useRef } = React;

function App() {
  const [toasts, setToasts] = useState([]);
  const tid = useRef(0);
  const route = useStore(s => ({ screen: s.routeScreen, ...s.routeParams }));
  const activeRole = useStore(s => s.activeRole);

  const go = (r) => {
    if (typeof r === 'string') r = { screen: r };
    storeActions.setRoute(r.screen, r);
  };

  const toast = (msg, icon = 'check') => {
    const id = ++tid.current;
    setToasts(t => [...t, { id, msg, icon }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 3200);
  };

  const home = ROLE_META[activeRole]?.home || 'd.dashboard';
  const s = route.screen || home;
  const m = { go, toast };

  const screen = (() => {
    switch (s) {
      case 'd.dashboard': return window.DashboardScreen ? <window.DashboardScreen {...m} /> : null;
      case 'd.collections': return window.CollectionListScreen ? <window.CollectionListScreen {...m} /> : null;
      case 'd.collectionDetail': return window.CollectionDetailScreen ? <window.CollectionDetailScreen id={route.id} {...m} /> : null;
      case 'd.search': return window.SearchScreen ? <window.SearchScreen {...m} /> : null;
      case 'p.dashboard': return window.ProductionDashboard ? <window.ProductionDashboard {...m} pushback={route.pushback} /> : null;
      case 'p.boms': return window.BomListScreen ? <window.BomListScreen {...m} /> : null;
      case 'p.bomDetail': return window.BomOverviewScreen ? <window.BomOverviewScreen id={route.id} tab={route.tab} {...m} /> : null;
      case 'p.bomUpload': return window.BomUploadScreen ? <window.BomUploadScreen {...m} /> : null;
      case 'p.validate': return window.BomValidationScreen ? <window.BomValidationScreen id={route.id} {...m} /> : null;
      case 'p.sourcing': return window.SourcingProgressScreen ? <window.SourcingProgressScreen id={route.id} {...m} /> : null;
      case 'p.results': return window.SourcingResultsScreen ? <window.SourcingResultsScreen id={route.id} {...m} /> : null;
      case 'p.procurement': return window.ProcurementPackageScreen ? <window.ProcurementPackageScreen id={route.id} {...m} /> : null;
      case 'projects': return window.ProjectsScreen ? <window.ProjectsScreen {...m} /> : null;
      case 'projectDetail': return window.ProjectDetailScreen ? <window.ProjectDetailScreen id={route.id} {...m} /> : null;
      case 'programs': return window.ProgramsScreen ? <window.ProgramsScreen {...m} /> : null;
      case 'programDetail': return window.ProgramDetailScreen ? <window.ProgramDetailScreen id={route.id} {...m} /> : null;
      case 'purchasingEmbed': return window.EmbeddedPurchasing ? <window.EmbeddedPurchasing req={route.req} tab={route.tab} {...m} /> : null;
      case 'inventoryEmbed': return window.EmbeddedInventory ? <window.EmbeddedInventory {...m} /> : null;
      case 'storageDetail': return window.StorageDetailScreen ? <window.StorageDetailScreen loc={route.loc} {...m} /> : null;
      case 'search': return window.SearchScreen ? <window.SearchScreen {...m} /> : null;
      case 'a.dashboard': return window.AdminDashboard ? <window.AdminDashboard {...m} /> : null;
      case 'a.users': return window.UserManagement ? <window.UserManagement {...m} /> : null;
      case 'a.config': return window.AdminConfiguration ? <window.AdminConfiguration tab={route.tab || 'decisionTraces'} {...m} /> : null;
      case 'a.waivers': return window.ForceWaiversLog ? <window.ForceWaiversLog {...m} /> : null;
      case 'a.audit': return window.AuditLog ? <window.AuditLog {...m} /> : null;
      case 'notifications': return window.NotificationsPage ? <window.NotificationsPage {...m} /> : null;
      default: return <EmptyState icon="alert" title="Screen not found" description={`No route for: ${s}`} />;
    }
  })();

  const crumbs = buildCrumbs(route, getState());
  const crumbDefs = crumbs.map((c, i, arr) => ({ label: c.label, go: (c.route && i < arr.length - 1) ? () => go(c.route) : null }));

  return (
    <div className="app">
      <window.Sidebar role={activeRole} go={go} />
      <div className="main">
        <window.TopRail role={activeRole} go={go} />
        <window.Breadcrumbs items={crumbDefs} />
        <div className="content">{screen}</div>
        <window.NotificationPanel go={go} />
        <window.SearchOverlay go={go} />
      </div>
      <div className="toasts">
        {toasts.map(t => (
          <div key={t.id} className="toast">
            <Icon name={t.icon} size={16} />{t.msg}
          </div>
        ))}
      </div>
    </div>
  );
}

if (typeof window !== 'undefined' && typeof ReactDOM !== 'undefined') {
  setTimeout(() => {
    const root = document.getElementById('root');
    if (root) ReactDOM.render(<App />, root);
  }, 50);
}
