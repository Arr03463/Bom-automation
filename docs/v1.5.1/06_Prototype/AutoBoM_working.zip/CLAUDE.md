# AutoBOM — Project Standards

Source of truth (v1.4): `uploads/AutoBOM_PRD_v1.4_clean.txt`,
`uploads/AutoBOM_Claude_Design_Package_v1.4_clean.txt`, `uploads/AutoBOM_Permissions_Matrix_v1.4_clean.txt`.
The v1.4 PRD is **integrative** — module packages (Purchasing v4, Inventory Activation v3, Designer/Production
Alignment) remain authoritative for their own scope; the PRD wins only on cross-workflow, roles, data-model,
and integration topics. Earlier v1.1 texts are superseded but kept for history.
Main build: `autobom/AutoBOM Platform.html`.

## v1.1 MVP scope — 4 active roles
**Designer · Production · Purchasing · Admin.** The Development role was fully designed in v1.0 and is
**deferred** — its screens, store actions, routes, and seed data stay in the repo but are hidden behind a
single flag (`DEV_ROLE_ENABLED = false` in `permissions.jsx`). Sidebar nav, role-switcher options, dashboards,
search results, notifications, and admin role lists all read that flag. Deep-linking to `/development/*`
renders a "Reserved for future release" notice — never a broken screen. Reactivation is a one-line flip.

## Platform boundary (PRD §1.3)
AutoBOM is **not** firmware management, design repository / CAD, source-code management, sensitive engineering
documentation storage, project requirements management, file storage (not OneDrive/SharePoint), or team
communication (not Teams/Slack). It is **Parts · Collections · BOMs · Sourcing · Procurement · Workflow handoffs
between Designer, Production, and Purchasing.**

## Architecture (locked in)
- **Shared global state** (`store.jsx`): one connected workflow engine. Designer → Production → Purchasing.
  Actions mutate global state and propagate notifications + audit across every role.
- **RBAC** (`permissions.jsx`): read-only by default; Admin assigns roles. **Two layers**: role-based defaults
  from `CAPS[role]` + **user-level overrides** (`user.overrides[]`). `can(action, { role, user })` combines both.
  The sidebar **role switcher is a PROTOTYPE affordance only** (tagged as such) — production uses the matrix.
- **Roles** (active MVP): Designer (engineering intent), Production (sourcing readiness), Purchasing (purchase
  execution), Admin (system config). **Deferred:** Development (emerald `#059669`) — see Future Expansion.
- **Collections (MVP):** only Designer Collections — violet, role=designer — "what parts should be used?" → feed
  into BOMs. Development Collections are deferred with the Development role.

## Inline part verification (FR-D06/7/8 — reusable pattern in `ui.jsx` → `<InlinePartVerify>`)
- Wherever a user enters manufacturer + MPN to verify a component (Designer exception response, Designer
  collection rejection response, any future engineering-review surface), Verify MUST NOT navigate the page.
- Sequential inline phases: `Searching Mouser… → Searching DigiKey… → Checking lifecycle…` then a result card
  with per-supplier stock / price / supplier-PN, lifecycle, recommended supplier, and three actions:
  **Use This Part**, **Search Again**, **View Full Details ↗** (opens `#/designer/search?q=<mpn>` in a new tab only).
- States: result found · no-match · partial · API unavailable. Never clear user-entered data on failure.
- Non-negotiable context preservation: the exception/record, every other row on the form, every typed note,
  every previously-confirmed replacement, and page scroll position all remain exactly as they were.

## Notification routing (every notification)
- **Purchasing is downstream of every review — it receives NO approve/reject/review notifications.** Dropping a
  request into the bucket is not a permission request. The only notifications a Purchasing user ever gets:
  (1) Order missing tracking (inline Add tracking — the sole Purchasing action), (2) informational status
  (batch fired, shipment received — optional, `kind:'fyi'`). Batch-failure notifications go to Admin, not Purchasing.
  Any pre-bucket check is the sender's own (within-role peer review, or the Designer↔Production exception handshake).
  David Okafor's panel is empty when nothing is missing tracking — that empty state is correct.
- **Purchasing can NEVER reject, decline, return-to-sender, or request resubmission.** No `rejectRequest`,
  `requestClarification`, or `resubmitRequest` emitter exists; no "Collection Rejected" / "Purchasing Rejection"
  card, no "Rejected by <Purchasing user>" attribution, no "Review & resubmit" response. The bucket is a one-way
  funnel — requests only move forward (sheet → order → tracking → receiving), never back. A concern that would
  have been a rejection is instead an UPSTREAM pre-submission check on the sender's side (stock, CPN, supplier
  split, budget code). To change a submitted request, the sender submits a new one.
- **A notification is a task handoff, not a link.** Route the clicker to the screen where THEY can resolve the
  task inside THEIR own workspace.
- Notification record shape: `routes: { designer?, production?, purchasing?, admin? }` keyed by role, plus
  `actionLabel`, `verb` (Resolve / Respond / Review / Validate / Investigate / Track), `sourceRole`, `targetRole`.
  `resolveNotificationRoute(notif, user, activeRole)` returns `{ route, switchTo? }`.
- **Multi-role users — Option A on notif clicks (auto-switch with notice).** Sticky role-context banner:
  `Switched to Production context — this task is assigned to Production. [Switch back to Designer]`.
- **Multi-role users — Option B on direct task-detail entry.** Never silently switch on deep-links; show explicit
  prompt `[Open in <role> workspace] [Stay in <current>]`. Only switch on user confirmation.
- Panel surface: `ACTION REQUIRED — <actionLabel>` headline, `<sourceObject> · Sent by <sourceRole> · <when>`,
  one action button using the `verb`. Generic "View" / "Open" reserved for FYI / shipped notifs.

## Scrolling & layout (every screen — FR-N04..05)
- Sidebar is **fixed**, never scrolls. Everything else (top rail, breadcrumbs, content, tables, dashboards) is
  **one unified scrollable page** using the browser's native scroll and native scrollbar.
- No inner scroll boxes inside content sections, tables, or panels.
- Sticky: top rail, table column headers, action bar.
- Design assuming hundreds of line items. Compression that hides information is a design failure.
- Desktop-first — laptop, large monitor, ultrawide. Mobile is read-only for order status only.

## Navigation & persistence (every screen — FR-N01..03 — `nav.jsx` is the router)
- URL-routed: every major view has a hash URL. Browser Back/Forward work in context. Deep links work.
- Breadcrumbs below the top rail on every page, fully clickable.
- Tabs (project/BOM/collection detail) reflected in URL (`?tab=`); switching never reloads or loses context.
- Workspace persistence via `useListState(key, defaults)` (sessionStorage): filters, search terms, sort order,
  scroll position restored on return.
- Related-object links on every detail view. No dead ends — every modal/slide-out has explicit close/back.

## Search (every screen — FR-S01..04 — `search.jsx` is the overlay)
- Primary search is a contextual overlay, not a page navigation. Top rail bar opens a dropdown anchored below it;
  **⌘K / Ctrl+K** opens a centred command palette. Page behind stays visible and interactive.
- Live results on every keystroke. Categorised: Components · Collections · BOMs · Projects · Requests · Orders.
- Ranking (`rankResults`): exact MPN → exact mfr+MPN → supplier PN → partial MPN → name → recents → related.
- Inline actions: open, preview, add to Collection, copy MPN, jump to related object.
- Escape closes and returns the user exactly where they were (scroll, filters, panels, selected row).
- **FR-S04 — search within tables.** BOM results table and Collection detail table have an inline text filter
  field (no navigation, no overlay) that narrows the visible rows on every keystroke.
- `/designer/search` is the advanced research surface for deep supplier comparison — never the default.

## Dashboard is the operational inbox (v1.3-rev — Task Center REMOVED)
- **The Task Center no longer exists** — no nav item, no `/[role]/tasks` route, no task-detail screen, no task-status
  state machine, no Task Center badge. The Dashboard is each role's operational inbox AND work surface. The module is
  `needs_attention.jsx` (`deriveAttention(state, role)` + `<NeedsAttention role go flashId>`).
- **Needs Attention** is the top section of every Dashboard. It shows ONLY items requiring the current user's action.
  Empty → "All caught up" green state (never a blank area). Sidebar Dashboard nav item is badged `[N]` with the
  Needs-Attention count (`attCountForRole`).
- **Every item is interactive** — never display-only. The card title navigates to full detail; the action button
  completes the common action. The most common action MUST be completable from the card without navigating away.
- **Inline expansion grows the card WITHIN page flow** — never a modal, overlay, or full-page takeover. Cancel
  collapses it back. Used for: rejection comment (≥10 char), replacement MPN entry (inline `<InlinePartVerify>`),
  tracking number, reassign user, confirm-before-run.
- **Live status**: run-sourcing shows an inline progress bar; immediate actions show a working→done state in place.
- **Per-role cards** (from v1.3-rev brief):
  - Designer: BOM exception (Respond → inline replacement rows + verify → Send to Production) · Stale sourcing
    (Re-check inline). (No "collection rejected" card — Purchasing has no reject action; a rejection event
    cannot exist. Bad requests are blocked by upstream checks before entering the bucket.)
  - Production: BOM awaiting sourcing (Run sourcing inline + live progress) · Replacements received (Re-source inline)
    · BOM awaiting validation (Review → navigates, deliberate). (No "purchasing rejection" card — same reason.)
  - Purchasing: Order missing tracking (Add tracking inline) — the ONLY Purchasing action in AutoBOM. Purchasing is
    an observation surface, NOT a review/approval role: NO "Request awaiting review" cards, NO Approve/Reject, NO
    checklist. Requests live in the bucket view at `/purchasing`; the Dashboard links to it as a read-only summary.
  - Admin: Failed job (Retry inline) · Stuck workflow >48h (Reassign inline) · DigiKey token expiring (Refresh inline)
    + System Status health rows.
- **Notification routing → Dashboard**: clicking an ACTION notification routes the clicker to THEIR OWN dashboard with
  the matching Needs Attention card scrolled into view + amber-flashed (`flashId` → `na-flash`). FYI/readonly notifs
  (order placed/shipped — verb View/Track) still deep-link to the object's status view. Multi-role auto-switch banner
  still applies. Never route to another role's workspace.

### v1.3-rev rejection criteria (15–18, additive to the 14)
15. Any Task Center screen, nav item, or route — it does not exist.
16. A Dashboard item that is display-only (must be actionable or navigable-to-detail).
17. An action that forces navigation away from the Dashboard for the common response.
18. Inline expansion that opens a modal / overlay / full-page takeover (must grow within page flow).

## Comments (every commentable object — FR-C01..03)
- `STATE.comments` is `{ [entityId]: [{ id, userId, name, role, when, body }] }`. `addComment(entityId, body)`
  stamps current user + active role + timestamp, returns the new id, writes an audit entry.
- `<CommentThread entityId>` (in `ui.jsx`) is the single render. Chronological, oldest→newest.
  Reserve visual space for threaded replies (future).
- Required on: Collections, BOMs, Exceptions, Procurement Requests, Purchase Orders, all
  approval/rejection screens. Comments cannot be deleted (audit weight).

## Collections are live workspaces
- Inline-editable on detail (active/draft/rejected only): name, description, project (dropdown).
- Per-row controls: edit qty, edit per-item note, remove (confirm), refresh sourcing for that part.
- Collection-level: Refresh sourcing for all parts.
- **Adding a part NEVER navigates.** Inline drawer (`<AddPartDrawer>`) — searches Mouser then DigiKey with phase
  indicators; result rows have qty + per-item note; confirm adds + clears for the next add.
- **New Collection** opens a create modal. Required: name, project, description, category, owner. Optional:
  tags, priority, related BOM. On save: id + audit + status=Draft, then route into the new detail page.
- Editing locked after submission except notes/comments. Locked banner explains why + who owns the next action.
- **FR-D05 — Stale data gate at Request to Order.** Before submitting, if any item's sourcing data is >24h old,
  show a warning with `[Re-check now]` (re-runs sourcing on stale items, refreshes timestamps) and
  `[Proceed with current data]` (writes a note onto the request). Never silently submit stale data.

## Purchasing — bucket model (Consolidated v2 — supersedes the Observation Surface's Required By)
- **Purchasing is a shared bucket, not a workflow role.** Every request from every project pools into one
  read-only bucket at `/purchasing` (`b.purchasing` → `PurchasingObservation`), filterable by any dimension,
  anchored on each part's CPN. Any view-access user can see it. No work UI (no Approve/Reject/Clarification/
  Order Execution/Mark Complete). Sidebar: **Dashboard · Purchasing** only.
- **Two streams, two timers.** One bucket split into **Critical** and **Main**, each with its own
  **Admin-configurable batch interval** (defaults: Critical 180 min, Main 360 min) that batches its contents to
  the Daily Purchasing List. Config lives in `system.batch.{critical,main}` and is edited in Admin → System Settings
  (`setBatchInterval`, plus a manual `flushBucket` escape hatch). Intervals are NEVER hard-coded.
- **Batch atomicity.** Timers never overlap (a firing batch waits for the current write to finish); each write is
  all-or-nothing (never a half-written row, never split a request across two batches). Failures surface to the
  Admin Dashboard failed-jobs and retry on the next run.
- **Critical flag REPLACES Required By / Urgency entirely.** There is NO Required By dropdown and NO Urgency
  dropdown on the Request to Order form — both removed. Per-line urgency is meaningless once items consolidate into
  2 supplier carts. The form has a single **Critical toggle** (boolean, default off): off → Main bucket, on →
  Critical bucket. Cannot be edited after submission. On the sheet's existing Urgency column AutoBOM writes only
  `Next Day` (Critical) or `2-Day` (Main) — never Amazon Prime, never free text. Request carries `critical` +
  `bucketState` (`QUEUED_MAIN` · `QUEUED_CRITICAL` · `WRITTEN` · `PURCHASED`/`PROCESSED`).
- **Observation surface layout**: (1) **Critical bucket** at top — flagged (danger band), count, timer countdown
  ("next batch in 47m"), empty state names the next run; (2) **Main bucket** — count, timer countdown, filters incl.
  a Critical (all/yes/no) dropdown; (3) **Order activity** — placed + awaiting placement; (4) **Shipment status** —
  in transit + recently received, tracking numbers are clickable carrier links. No Required-by column anywhere.
- **OneDrive live write** (`Daily Purchasing List`): live integration, not export/download. 12 columns unchanged;
  vendor is a column not a grouping; Mouser/DigiKey rows only; CPN is NOT written to the sheet; stop touching a row
  once Status is set. Banner states both cadences + atomic-write guarantee.
- **Dashboard untouched** for all four roles.
- **v2 rejection criteria** (enforce): any Required By/Urgency dropdown on the form (only the Critical flag exists);
  any per-line urgency written to the sheet (only 2-Day/Next Day); immediate per-submission sheet writes (must be
  batched); batches that interleave or leave half-writes; hard-coded/fixed timer intervals (must be Admin-config);
  any Order Execution / cart-building / work UI on the Purchasing screen; new sheet columns or a CPN column.
- **Out of MVP** (do not design/stub): auto supplier-order creation, credit-line purchasing, auto placement, auto
  shipment API sync, sub-threshold auto-purchase.

## Purchasing — single OBSERVATION SURFACE (Consolidated Reframe — SUPERSEDED by the bucket model above)
- **Purchasing is NOT a workflow role.** One screen at `/purchasing` (`b.purchasing` → `PurchasingObservation`),
  read-only. It answers "what is happening?" and never performs work. The earlier 3-screen split (Requests /
  Order Execution / Purchase Orders) is **discarded**; those routes alias to the observation surface, request
  detail (`b.requestReview`) is read-only. Sidebar: **Dashboard · Purchasing** only.
- **No work UI anywhere on the surface**: no Approve/Reject, no Request Clarification, no Order Execution, no
  cart-building, no Mark Complete. Ordering happens on the supplier sites + the Daily Purchasing List.
- **Three stacked read-only regions**: (1) Consolidated requests — every in-flight request, all suppliers/projects,
  columns Request · Project · Project class · Requester · Required by · Supplier · Items · Est. total · Status ·
  Submitted, filters are dropdowns only (supplier/project/requester/status); (2) Order activity — placed +
  awaiting placement (information, not a task list); (3) Shipment status — in transit + recently received,
  tracking numbers are clickable carrier links.
- **OneDrive live write** (`Daily Purchasing List`): the handoff is a **live write, not an export/download**.
  Show a live-integration banner. The 12-column sheet is unchanged; AutoBOM appends Mouser/DigiKey rows
  chronologically (vendor is a column, never a grouping), updates price/qty pre-placement, stops once Status is set.
  Failures surface to the Admin Dashboard (failed jobs) and retry. CPN is NOT written to this sheet.
- **Required By replaces Urgency** on the Request to Order form — fixed dropdown (Tomorrow · Friday · Next week ·
  Two weeks · Flexible), required, no free typing. Mapped to the sheet's existing Urgency column on write
  (Tomorrow→Next Day, Friday→2-Day, Next week/Two weeks→Ground, Flexible→Ground; never Amazon Prime). The word
  "Urgency" must not appear on any AutoBOM form.
- **Dashboard untouched** — the interactive Needs Attention dashboard stays for all four roles incl. Purchasing.
- **Out of MVP** (do not design/stub/reserve UI): auto supplier-order creation, credit-line purchasing, auto order
  placement, auto shipment API sync, sub-threshold auto-purchase.

## Purchasing — three working screens (Purchasing Refinement — SUPERSEDED by the Observation Surface above)
- **Dashboard is unchanged** — the v1.3-rev interactive Needs Attention dashboard stays for ALL roles, Purchasing
  included. The fix was never the Dashboard: Purchasing had only ONE working screen (Requests) absorbing the whole
  job, so the Dashboard had nowhere distinct to route. Splitting Purchasing into three screens gives it distinct
  destinations like Designer/Production/Admin already have. Do not rebuild the Dashboard.
- **Requests (`b.requests`) — approval ONLY.** Contains the review/approval workflow and nothing about carts,
  ordering, or tracking. Three-way outcome per request: **Approve** → moves to Order Execution (ownership stays
  Purchasing) · **Reject** → returns to Production with required ≥10-char comment · **Request Clarification** → asks
  Production a question, request STAYS with Purchasing (not handed back), resumes when answered. Plus Comment.
- **Order Execution (`b.orderExec`) — NEW.** Turns an approved request into placed supplier orders. **Plain business
  language only — never "API", "API Mode", or developer wording on any button/label.** Flow: Generate Supplier Orders
  (one per supplier) → Prepare Orders → Launch Supplier Site (opens the site) → person places manually → Mark
  Complete. CSV is NOT a workflow step — it's a secondary audit action (Export CSV / Download Audit Package).
- **Purchase Orders (`b.orders`)** — manages orders AFTER placement: add tracking, update shipment status, mark
  received, view supplier orders.
- **Shipments (`b.shipments`) — NEW.** Tracks physical movement. Each `Shipment` object: id, carrier, trackingNumber,
  supplier, status, expectedDelivery, actualDelivery. Chain: Request → Purchase Order → Shipment → Received. One
  Shipment object drives every role's delivery view. Tracking entry is manual now, structured so a future carrier
  API sync drops in without redesign.
- **Purchasing nav order:** Dashboard · Requests · Order Execution · Purchase Orders · Shipments.

## Customer Part Number (CPN) — auto-generated, read-only everywhere
- Generated automatically when a part first becomes a sourceable line (BOM normalisation, or Collection prep for a
  Request to Order). Exists on every line before it reaches Purchasing. **Read-only for everyone — never an input.**
- Display in **monospace**. Bind to the stored value; do NOT hard-code or build a generator/editor UI — the exact
  format is still being finalised. Working format e.g. `TVCA-B052-AJ-001` (project) / `RD-C014-AJ-001` (R&D):
  bucket · source object id · owner initials · line number.
- Purpose: receiving + traceability (reverse lookup → project, source object, line). Sent to suppliers during
  supplier-order generation as the only AutoBOM-populated supplier-side field (Mouser, DigiKey).

## Input principle — minimise typing, maximise selection (platform-wide)
- Wherever a value has a known set of valid answers, the user **selects** it (dropdown/segmented/picker) — never
  types it from scratch. Free typing is reserved for genuinely open content (notes, comments, descriptions).
- Apply opportunistically wherever it fits; it's a principle, not a mandate to rebuild every screen at once.

## Multi-supplier ordering (Purchasing — FR-PU01..06)
- A `ProcurementRequest` produces **one PO per supplier present** in its lines. Composite IDs: `PO-XXX-M`, `PO-XXX-DK`.
- Order Placement is a per-supplier **checklist** — each supplier row is independent, has its own substeps
  (Prepare → Place → Mark Ordered → Add tracking), its own status, and can be processed in any order.
- Status `partially-ordered` (outlined blue) covers the in-between state. Roll-up: any complete + any not-complete
  → PARTIALLY ORDERED · all complete → ORDERED · none complete → APPROVED.
- Notifications fire twice in mixed-supplier requests: first-supplier-placed and last-supplier-placed.
- POs list groups children under the parent request.
- **FR-PU05 — Customer reference required.** Pre-filled with the request ID; cannot be submitted blank.
- **FR-PU06 — Rejection requires ≥10-char comment.** Rejection routes notif to Designer/Production Task Center
  with the comment shown inline.

## Production exception handling (FR-P01..06)
- **FR-P05 — Cancel sourcing preserves partial results.** Completed lines stay; BOM returns to NORMALISED.
  Partial-results banner offers `[Re-run sourcing on unsourced lines]`.
- **FR-P06 — PartsBox failure non-blocking.** Submission to Purchasing still proceeds; the procurement package
  view shows the error with `[Retry]` and tags the submitted request with a warning flag.

## Admin (FR-A01..06)
- **FR-A03** — Hybrid users: role switcher visible only for multi-role users; switching shows explicit notice.
  Audit captures both user identity and active role.
- **FR-A04 — Override actions require reason (min 10 chars) + confirmation.** The reason becomes a permanent audit
  event with before/after state.
- **FR-A05 — System Status tab.** Health rows for database, Redis/job queue, Mouser API, DigiKey API, PartsBox API.
  DigiKey token expiry warning with `[Refresh]` action.

## Future expansion (deferred, reserved in code)
- Development role + Investigation / Improvement Recommendation / Rework Package / Firmware Release + Handshake
  workflow + Development Collections (emerald #059669). Reactivate when the Designer → Production → Purchasing
  pipeline is validated in production.
- Review & Share workflows: Share Collection, Share BOM, Request Review, Junior → Senior review chain.
- Inventory / receiving / "the wall" — barcode scanning, order attribution.
- Email / Microsoft Teams notification channels (architecture reserved; UI deferred).
- Additional suppliers beyond Mouser and DigiKey (Newark already in real BOM data).
